﻿namespace ConsumeApi.Models
{
    public class Emp
    {

      
            public int id { get; set; }
            public string name { get; set; }
            public string email { get; set; }
            public float salary { get; set; }
        

    }
}
